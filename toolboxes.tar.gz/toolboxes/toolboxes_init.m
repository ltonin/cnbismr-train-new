% 2010-11-30  Michele Tavella <michele.tavella@epfl.ch>
mtpath_include('$EEGC3_ROOT/toolboxes/biosig', 1);
mtpath_include('$EEGC3_ROOT/toolboxes/cva');
mtpath_include('$EEGC3_ROOT/toolboxes/dptools');
mtpath_include('$EEGC3_ROOT/toolboxes/gaussian');
mtpath_include('$EEGC3_ROOT/toolboxes/gdfmatlab');
mtpath_include('$EEGC3_ROOT/toolboxes/gkde');
mtpath_include('$EEGC3_ROOT/toolboxes/subdir');
mtpath_include('$EEGC3_ROOT/toolboxes/xml4mat');
