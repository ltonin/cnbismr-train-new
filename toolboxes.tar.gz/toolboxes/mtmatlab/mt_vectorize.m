% 2010-10-23  Michele Tavella <michele.tavella@epfl.ch> 
% function v = mt_vectorize(m)
function v = mt_vectorize(m)
	v = m(:);
