% 2010-08-23  Michele Tavella <michele.tavella@epfl.ch>
% n = sq(m)
function n = sq(m)
	n = squeeze(m);
