% 2010-08-23  Michele Tavella <michele.tavella@epfl.ch>
% n = s(m, d)
function n = s(m, d)
	n = size(m, d);
